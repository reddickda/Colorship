﻿using UnityEngine;
using System.Collections;

public class buttonEvents : MonoBehaviour {

	public void onMainMenuClick(){
		Application.LoadLevel ("MainMenu");
		}

public void onPlayClick(){
		Application.LoadLevel ("Colorship");
		PauseManager.death = false;
		PauseManager.pause = false;

}
}