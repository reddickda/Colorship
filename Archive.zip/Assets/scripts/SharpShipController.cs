using UnityEngine;
using System.Collections;

public class SharpShipController : enemyShipController {
	public float sideSpeed;
	public float farLeft;
	private float time;

	public float howLongTilSpawn;
	public GameObject projectile1;
	public GameObject projectile2;
	public GameObject projectile3;


	bool doneGoingLeft = false;
	// Use this for initialization
	public override void Start () {
		time = 0;
		InvokeRepeating ("Shoot", 2.0f, .4f);

	}
	protected override void Shoot(){
		if (PauseManager.pause) {
			
			return;
		}
		Instantiate (projectile1, transform.position, Quaternion.identity);
		Instantiate (projectile2, transform.position, Quaternion.identity);
		projectile1.rigidbody2D.velocity = new Vector2 (0, -5);
		projectile2.rigidbody2D.velocity = new Vector2 (-2, -5);




	
	

		}
	
	// Update is called once per frame
	public override void Update () {
	

				if (Time.time > howLongTilSpawn && projectile2 != null && projectile3 != null) {
						projectile2.transform.position = new Vector2 (-10, gameObject.transform.position.y);
						projectile3.transform.position = new Vector2 (10, gameObject.transform.position.y);

						if (doneGoingLeft == false) {
								rigidbody2D.velocity = new Vector2 (sideSpeed, 0);
						}
						if (transform.position.x <= farLeft) {
								doneGoingLeft = true;
								rigidbody2D.velocity = new Vector2 (-sideSpeed, 0);
						}
				}
		}
		 public override void OnTriggerEnter2D(Collider2D other){
			
			if(other.tag == "deadly" && other.gameObject.tag != "deadlyenemy"){
				//Destroy(gameObject.name.Contains("bullet"));
				//Debug.Log("Dead!");
				//Application.LoadLevel(0);
			Destroy(other.gameObject);
			}
			
		}
		
		
		
		
		public override void OnCollisionEnter2D(Collision2D other){
			if (other.gameObject.tag == "deadly" && other.gameObject.tag != "deadlyenemy") {
				//Debug.Log ("Dead!");
				//Application.LoadLevel (0);
			Destroy(other.gameObject);

			}
			
			
		}


	}


