﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BossSpawner : MonoBehaviour {
	private static BossSpawner bossSpawner;
	public GameObject boss;
	public GameObject deadMenu;
	bool isSpawned = false;
	// Use this for initialization
	void Start () {
		bossSpawner = this;
	}

	public static BossSpawner getInstance(){

		return bossSpawner;
	}
	public void spawn(){
		if (isSpawned == false) {
			Instantiate (boss, new Vector3 (.2f, 16.1f, 3f), Quaternion.identity);
			isSpawned = true;
				}

		}
	public void won(){
		deadMenu.GetComponent<Canvas> ().enabled = true;
		PauseManager.pause = true;
		GameObject.Find ("Status").GetComponent<Text> ().text = "You win!";
	}
}
