﻿using UnityEngine;
using System.Collections;

public class BossManager : MonoBehaviour {
	public Ships color;
	public GameObject bossBullet;
	public float bulletTime;
	public int health;
	private float time;
	public Vector3 offset;
	public bool damagable = true;
	public float top;
	public float speed;
	public AudioSource au_bossSong;
	public float leftBound;
	public float rightBound;
	 bool initialPush = false;
	bool headDam = false;

	bool stopped = false;

	public GameObject[] parts;
	GameObject head;


	// Use this for initialization
	void Start () {

		au_bossSong.Play ();
		rigidbody2D.velocity = new Vector2 (0, -speed);
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time - time > bulletTime) {
			
			Instantiate (bossBullet, transform.position + offset, Quaternion.identity);
			time = Time.time;
		}
		if (parts [0] != null) {
			head = parts[0];
			headDam = (parts[1] == null && parts[2] == null);
			if((parts[1] == null && parts[2] == null)){

				if(!(initialPush)){
					initialPush = true;
					rigidbody2D.velocity = new Vector2 (-3, 0);
				}

				else if ( transform.position.x <= leftBound){
					rigidbody2D.velocity = new Vector2 (3, 0);
				}
				else if(transform.position.x >= rightBound){
						rigidbody2D.velocity = new Vector2 (-3, 0);
					}
				}
			}
				
		bool alive = false;

		for (int i = 0; i < parts.Length; i++) {
			if(parts[i] != null){
				alive = true;
				break;
			}
				}
		if (!alive) {

			BossSpawner.getInstance().won ();
			Destroy(this.gameObject);
			return;
				}
		if (transform.position.y <= top) {
			if (!stopped){
			rigidbody2D.velocity = new Vector2 (0,0);
			stopped = true;
			}
				}
	}
	void OnTriggerEnter2D(Collider2D other){
		if (damagable) {
			if(this == parts[0] && headDam){
			if (other.gameObject.name.Contains ("bullet")) {
				Ships ships = other.gameObject.GetComponent<bulletController>().bulletColor;
				if (ships == color) {
					health--;
				}
				if(health == 0){
					Destroy(this.gameObject);
				}
				Destroy(other.gameObject);
				}
			}
				else if (this != parts[0]){
					if (other.gameObject.name.Contains ("bullet")) {
						Ships ships = other.gameObject.GetComponent<bulletController>().bulletColor;
						if (ships == color) {
							health--;
						}
						if(health == 0){
							Destroy(this.gameObject);
						}
						Destroy(other.gameObject);

				}
			}	
		}
	}
}
