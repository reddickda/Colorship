﻿using UnityEngine;
using System.Collections;

public class BossDamaged : MonoBehaviour {
	public Ships color;
	public GameObject bossBullet;
	public float bulletTime;
	public int health;
	private float time;
	public Vector3 offset;
	public bool damagable = true;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Time.time - time > bulletTime) {

			Instantiate (bossBullet, transform.position + offset, Quaternion.identity);
			time = Time.time;
			}
				
	}

	void OnTriggerEnter2D(Collider2D other){
		if (damagable) {
			if (other.gameObject.name.Contains ("bullet")) {
				Ships ships = other.gameObject.GetComponent<bulletController>().bulletColor;
				if (ships == color) {
					health--;
				}
				if(health == 0){
					Destroy(this.gameObject);
				}
				Destroy(other.gameObject);
			}	
				}
		}

}
